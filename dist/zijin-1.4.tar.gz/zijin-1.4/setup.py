from setuptools import setup

setup(name='zijin',
      version='1.4',
      description='zijin test package',
      url='https://github.com/xxh13/zijin_.git',
      author='xxh13',
      author_email='15850781776@163.com',
      license='MIT',
      packages=['zijin'],
      install_requires=['bson'],
      zip_safe=False,
      include_package_data=True
)
